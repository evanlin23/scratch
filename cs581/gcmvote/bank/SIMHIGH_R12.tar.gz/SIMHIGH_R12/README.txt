AI-assisted (Claude), exploration code for CS581 project
SIMHIGH_R12 rep bank (AliSim protein, gen.sh seeds; one MAGUS draw, paper flags). gcmgen rep layout:
inputs/subalignments  MAGUS's 25 subset alignments
inputs/backbones      MAGUS's 10 L-INS-i backbones (backbone_N_mafft.txt), 200 seqs each
aligned/<tool>/       the same 10 backbone sets realigned with fftns2 / fftns2-op3 (gg.py recipe/hard), and linsi
sets/s0               unaligned backbone sequence sets
true.fasta            reference (uppercased simulated alignment); true_tree.nwk = AliSim true tree
unaligned.fasta       input sequences; magus.json = MAGUS end-to-end score row; subsets.json = MAGUS's subset
                      order from vote.py's magus run (absolute paths of the original machine)
Use: extract to DIR, then  python3 cs581/gcmvote/code/vote.py DIR/SIMHIGH_R12 VARIANT
