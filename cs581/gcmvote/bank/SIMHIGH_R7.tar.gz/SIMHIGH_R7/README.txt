AI-assisted (Claude), exploration code for CS581 project
SIMHIGH_R7 rep bank (AliSim protein, gen.sh seeds tree 707 / seq 713). gcmgen rep layout: inputs/subalignments (MAGUS's
25 L-INS-i subset alignments), inputs/backbones (MAGUS's 10 L-INS-i backbones x 200 seqs, backbone_N_mafft.txt),
sets/s0 (the 10 backbone sequence sets), aligned/{linsi,fftns2,fftns2-op3}/s0 (gg.py's backbone alignments of those
sets), true.fasta (reference), true_tree.nwk, unaligned.fasta, magus.json (full MAGUS run score),
subsets.json (MAGUS's subset order = GCM node-id order, relative paths). Merged outputs excluded.
