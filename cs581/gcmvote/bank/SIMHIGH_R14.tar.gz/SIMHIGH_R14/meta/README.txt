AI-assisted (Claude), exploration code for CS581 project
SIMHIGH_R14 rep bank (gcmgen layout; merge-only reruns without MAGUS).
inputs/subalignments  MAGUS's 25 subset alignments (draw 0, paper flags)
inputs/backbones      MAGUS's 10 L-INS-i backbones (200 seqs each), backbone_N_mafft.txt
aligned/<tool>/s0     the same 10 backbone sequence sets aligned by linsi / fftns2 / fftns2-op3 (gg.py cache)
sets/s0               the backbone sequence sets
true.fasta            AliSim true alignment (reference for FastSP); tree.nwk = true tree
unaligned.fasta       input sequences; magus.json = MAGUS run summary
meta/subsets.json     MAGUS's subset order (node ids are offsets in this order), paths relative to the rep root
Untar, then: python3 cs581/gcmvote/code/vote.py <dir> VARIANT   or   gg.py run <dir> VARIANT
