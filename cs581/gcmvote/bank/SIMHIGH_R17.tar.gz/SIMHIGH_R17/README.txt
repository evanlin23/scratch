AI-assisted (Claude), exploration code for CS581 project
SIMHIGH_R17 rep bank (AliSim LG+G4, gcmtrees gen.sh seeds; one MAGUS draw, paper flags, 25 subsets, 10 L-INS-i backbones).
inputs/subalignments + inputs/backbones = everything a merge-only run needs (vote.py REPDIR VARIANT).
true.fasta = reference alignment for FastSP; true_tree.nwk = AliSim true tree; unaligned.fasta = input sequences;
sets/ = backbone sequence sets; subsets.json = MAGUS subset order recorded by vote.py (paths from the original machine); magus.json = MAGUS run metrics.
